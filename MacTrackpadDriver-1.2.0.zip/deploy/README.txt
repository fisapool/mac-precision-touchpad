# Mac Trackpad Driver for Windows

Version: 1.2.0
Build Date: 2025-03-11
Configuration: Release

## Quick Start

1. Run the installer: Tools\Install.bat (as Administrator)
2. Restart your computer

## Contents

- Driver\ - Driver files
- Documentation\ - User guides and technical documentation
- Tools\ - Installation and maintenance utilities

## Support

For support, please visit the project repository.
